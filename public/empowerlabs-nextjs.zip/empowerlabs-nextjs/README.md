# EMPOWER Labs — Next.js + WordPress + Supabase

Full-stack rebuild of empowerlabs.ai: Next.js 14 (App Router) for the frontend,
WordPress as a headless CMS for blog content, and Supabase as the database backend.

---

## Stack

| Layer       | Technology              | Purpose                               |
|-------------|-------------------------|---------------------------------------|
| Frontend    | Next.js 14 App Router   | All pages, routing, SSR/SSG           |
| Styling     | Tailwind CSS            | Utility-first CSS                     |
| Database    | Supabase (PostgreSQL)   | Subscribers, applications, inquiries  |
| CMS         | WordPress REST API      | Blog posts, managed in WP admin       |
| Hosting     | Vercel / VPS + nginx    | See deployment section                |

---

## Project Structure

```
empowerlabs-nextjs/
├── app/
│   ├── globals.css          # Global styles + Tailwind
│   ├── layout.tsx           # Root layout, Nav, announce bar
│   ├── page.tsx             # Homepage (fetches WP blog posts)
│   ├── cohort/page.tsx      # Cohort page
│   ├── teams/page.tsx       # Teams page
│   └── api/
│       ├── subscribe/       # POST /api/subscribe → Supabase
│       ├── apply/           # POST /api/apply → Supabase
│       └── team-inquiry/    # POST /api/team-inquiry → Supabase
├── components/
│   ├── Nav.tsx              # Sticky nav, mobile menu
│   ├── Footer.tsx
│   ├── Ticker.tsx           # Infinite scroll logo ticker
│   ├── Newsletter.tsx       # Email form → /api/subscribe
│   ├── EmperorCards.tsx     # 7 EMPOWER value driver cards
│   └── AnimateIn.tsx        # Scroll reveal wrapper component
├── lib/
│   ├── supabase.ts          # Supabase client (browser + server)
│   └── wordpress.ts         # WordPress REST API helpers
├── supabase/
│   └── schema.sql           # Run in Supabase SQL editor
├── nginx.conf               # nginx config: Next.js + WordPress on same domain
└── .env.local.example       # Copy to .env.local and fill in
```

---

## Step 1: Supabase Setup (5 minutes)

1. Create a free account at **supabase.com**
2. Create a new project (choose a region close to you)
3. Go to **SQL Editor → New Query**
4. Paste the entire contents of `supabase/schema.sql` and click **Run**
5. Go to **Settings → API**
6. Copy:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY`

---

## Step 2: Environment Variables

```bash
cp .env.local.example .env.local
```

Then edit `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciO...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciO...

# Your WordPress site (for blog posts)
WORDPRESS_URL=https://empowerlabs.ai

NEXT_PUBLIC_SITE_URL=https://empowerlabs.ai
```

---

## Step 3: Install & Run

```bash
npm install
npm run dev
# Open http://localhost:3000
```

---

## Step 4: WordPress Setup

### Option A — WordPress at /blog (same domain)

Your WordPress is at `empowerlabs.ai/blog`.
Next.js is at `empowerlabs.ai` (root).
Set `WORDPRESS_URL=https://empowerlabs.ai`.

Deploy the `nginx.conf` on your server — it routes `/blog/*` to WordPress
and everything else to Next.js.

### Option B — WordPress on a subdomain (easiest)

Set up WordPress at `cms.empowerlabs.ai`.
Set `WORDPRESS_URL=https://cms.empowerlabs.ai`.
No nginx trickery needed.
Next.js fetches posts from the WP REST API at that subdomain.

### Option C — WordPress stays at root (full migration)

Move WordPress to `old.empowerlabs.ai` or a staging URL.
Deploy Next.js at `empowerlabs.ai`.
WordPress is only used as a headless CMS.

### WordPress REST API — verify it works

Visit this URL in your browser to confirm posts are accessible:
```
https://your-wordpress-domain.com/wp-json/wp/v2/posts?per_page=3
```
You should see a JSON array of posts. If you get a 404, go to
WordPress Admin → Settings → Permalinks → Save Changes (re-registers REST API routes).

---

## Step 5a: Deploy to Vercel (recommended, easiest)

```bash
npm install -g vercel
vercel login
vercel
```

Or connect your GitHub repo at **vercel.com**:
1. Push this folder to a GitHub repo
2. Import project at vercel.com
3. Add all environment variables in **Settings → Environment Variables**
4. Deploy

Vercel automatically handles:
- SSL certificates
- Global CDN
- Preview deployments per PR
- Next.js image optimization

---

## Step 5b: Deploy to VPS alongside WordPress

If WordPress is already running on your VPS:

```bash
# On your server
git clone https://github.com/your-repo/empowerlabs-nextjs.git
cd empowerlabs-nextjs
npm install
cp .env.local.example .env.local
# Edit .env.local with real values
npm run build

# Install PM2 to keep it running
npm install -g pm2
pm2 start npm --name "empowerlabs" -- start
pm2 startup   # Auto-start on server reboot
pm2 save

# Deploy nginx config
sudo cp nginx.conf /etc/nginx/sites-available/empowerlabs.ai
sudo ln -s /etc/nginx/sites-available/empowerlabs.ai /etc/nginx/sites-enabled/
sudo nginx -t   # Test config
sudo systemctl reload nginx

# SSL with Let's Encrypt
sudo certbot --nginx -d empowerlabs.ai -d www.empowerlabs.ai
```

---

## Supabase Tables

### `subscribers`
| Column    | Type    | Description                          |
|-----------|---------|--------------------------------------|
| id        | uuid    | Primary key                          |
| email     | text    | Unique email address                 |
| source    | text    | 'newsletter' / 'cohort' / 'teams'    |
| confirmed | boolean | Email confirmed (for double opt-in)  |
| created_at| timestamptz | When they subscribed             |

### `cohort_applications`
| Column    | Type    | Description                          |
|-----------|---------|--------------------------------------|
| id        | uuid    | Primary key                          |
| full_name | text    | Applicant name                       |
| email     | text    | Email address                        |
| company   | text    | Company name (optional)              |
| role      | text    | Job title (optional)                 |
| message   | text    | Application message                  |
| status    | text    | pending / reviewed / accepted / rejected |
| created_at| timestamptz |                                  |

### `team_inquiries`
| Column    | Type    | Description                          |
|-----------|---------|--------------------------------------|
| id        | uuid    | Primary key                          |
| full_name | text    |                                      |
| email     | text    |                                      |
| company   | text    |                                      |
| team_size | text    | '10-25' / '25-50' / '50-100' / etc  |
| message   | text    |                                      |
| status    | text    | pending / contacted / converted      |

View all data in **Supabase Dashboard → Table Editor**.

---

## WordPress Custom Post Types (optional)

To manage testimonials in WordPress instead of hardcoding them, add to
your theme's `functions.php`:

```php
add_action('init', function() {
  register_post_type('testimonials', [
    'public'       => true,
    'show_in_rest' => true,   // Enables REST API access
    'labels'       => ['name' => 'Testimonials', 'singular_name' => 'Testimonial'],
    'supports'     => ['title', 'editor', 'custom-fields'],
  ]);
});
```

Then in Next.js use `getTestimonials()` from `lib/wordpress.ts`.

---

## Available API Routes

| Route               | Method | Body                          | Description           |
|---------------------|--------|-------------------------------|-----------------------|
| `/api/subscribe`    | POST   | `{email, source?}`            | Subscribe to newsletter |
| `/api/apply`        | POST   | `{full_name, email, company?, role?, team_size?, message?}` | Cohort application |
| `/api/team-inquiry` | POST   | `{full_name, email, company?, team_size?, message?}` | Teams inquiry |

---

## Updating Content

- **Page copy**: Edit the `.tsx` files in `app/` directly
- **Blog posts**: Write in WordPress admin as normal — Next.js fetches automatically
- **EMPEROR cards**: Edit `components/EmperorCards.tsx`
- **Testimonials**: Edit `app/page.tsx` (or move to WordPress CPT)
- **Logo ticker**: Edit `components/Ticker.tsx`

---

## Adding Stripe Payments

When you're ready to add paid enrollment:

```bash
npm install stripe
```

Create `app/api/checkout/route.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' })

export async function POST(req: NextRequest) {
  const { priceId } = await req.json()

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{ price: priceId, quantity: 1 }],
    mode: 'payment',
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/success`,
    cancel_url:  `${process.env.NEXT_PUBLIC_SITE_URL}/cohort`,
  })

  return NextResponse.json({ url: session.url })
}
```

Add `STRIPE_SECRET_KEY` and `STRIPE_COHORT_PRICE_ID` to `.env.local`.
