import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { full_name, email, company, role, team_size, message } = body

    // Validate required fields
    if (!full_name?.trim()) {
      return NextResponse.json({ error: 'Full name is required.' }, { status: 400 })
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }

    // Save application to Supabase
    const { data, error } = await supabaseAdmin
      .from('cohort_applications')
      .insert({
        full_name: full_name.trim(),
        email:     email.toLowerCase().trim(),
        company:   company?.trim() || null,
        role:      role?.trim() || null,
        team_size: team_size || null,
        message:   message?.trim() || null,
        status:    'pending',
      })
      .select('id')
      .single()

    if (error) {
      console.error('Supabase cohort application error:', error)
      return NextResponse.json({ error: 'Failed to submit application. Please try again.' }, { status: 500 })
    }

    // Also subscribe the email to newsletter
    await supabaseAdmin
      .from('subscribers')
      .upsert(
        { email: email.toLowerCase().trim(), source: 'cohort' },
        { onConflict: 'email', ignoreDuplicates: true }
      )

    // Optional: Send notification email to yourself
    // if (process.env.RESEND_API_KEY) {
    //   await fetch('https://api.resend.com/emails', {
    //     method: 'POST',
    //     headers: {
    //       'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
    //       'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify({
    //       from: 'onboarding@resend.dev',
    //       to: process.env.NOTIFICATION_EMAIL,
    //       subject: `New Cohort Application: ${full_name}`,
    //       html: `<p>New cohort application from <strong>${full_name}</strong> (${email})</p>
    //              <p>Company: ${company || 'N/A'}</p>
    //              <p>Role: ${role || 'N/A'}</p>
    //              <p>Application ID: ${data.id}</p>`,
    //     }),
    //   })
    // }

    return NextResponse.json({
      success: true,
      message: 'Application received! We\'ll be in touch within one business day.',
      id: data.id,
    })
  } catch (err) {
    console.error('Apply route error:', err)
    return NextResponse.json({ error: 'Server error. Please try again.' }, { status: 500 })
  }
}
