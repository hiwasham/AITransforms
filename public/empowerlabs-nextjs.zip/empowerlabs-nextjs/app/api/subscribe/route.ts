import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  try {
    const { email, source = 'newsletter' } = await req.json()

    // Validate
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }

    const validSources = ['newsletter', 'cohort', 'teams']
    const safeSource = validSources.includes(source) ? source : 'newsletter'

    // Upsert to Supabase (no error if email already exists)
    const { error } = await supabaseAdmin
      .from('subscribers')
      .upsert(
        { email: email.toLowerCase().trim(), source: safeSource },
        { onConflict: 'email', ignoreDuplicates: true }
      )

    if (error) {
      console.error('Supabase subscriber error:', error)
      return NextResponse.json({ error: 'Failed to subscribe. Please try again.' }, { status: 500 })
    }

    return NextResponse.json({ success: true, message: 'Subscribed successfully.' })
  } catch (err) {
    console.error('Subscribe route error:', err)
    return NextResponse.json({ error: 'Server error. Please try again.' }, { status: 500 })
  }
}
