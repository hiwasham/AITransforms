import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { full_name, email, company, team_size, message } = body

    if (!full_name?.trim()) {
      return NextResponse.json({ error: 'Full name is required.' }, { status: 400 })
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'Valid email is required.' }, { status: 400 })
    }

    const { data, error } = await supabaseAdmin
      .from('team_inquiries')
      .insert({
        full_name: full_name.trim(),
        email:     email.toLowerCase().trim(),
        company:   company?.trim() || null,
        team_size: team_size || null,
        message:   message?.trim() || null,
        status:    'pending',
      })
      .select('id')
      .single()

    if (error) {
      console.error('Supabase team inquiry error:', error)
      return NextResponse.json({ error: 'Failed to submit. Please try again.' }, { status: 500 })
    }

    // Also subscribe
    await supabaseAdmin
      .from('subscribers')
      .upsert(
        { email: email.toLowerCase().trim(), source: 'teams' },
        { onConflict: 'email', ignoreDuplicates: true }
      )

    return NextResponse.json({
      success: true,
      message: 'Request received! We\'ll be in touch within one business day.',
      id: data.id,
    })
  } catch (err) {
    console.error('Team inquiry route error:', err)
    return NextResponse.json({ error: 'Server error. Please try again.' }, { status: 500 })
  }
}
