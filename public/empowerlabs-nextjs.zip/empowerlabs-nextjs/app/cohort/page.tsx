import Link from 'next/link'
import Newsletter from '@/components/Newsletter'
import Footer from '@/components/Footer'
import AnimateIn from '@/components/AnimateIn'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Live Cohort | EMPOWER Labs',
  description: 'Document your business brain in 5 weeks. The only program that takes you from founder-dependent to AI-augmented.',
}

export default function CohortPage() {
  return (
    <>
      {/* ── HERO ── */}
      <section className="bg-zinc-950 text-white text-center relative overflow-hidden pt-24 pb-0">
        <div className="absolute inset-0 animate-glow pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 85% 65% at 50% -5%, rgba(37,99,235,.42) 0%, transparent 68%)' }} />
        <div className="relative z-10 px-6 pb-16">
          <AnimateIn>
            <div className="inline-flex items-center gap-2 bg-white/7 border border-white/13
              rounded-full px-4 py-1.5 text-[0.76rem] font-semibold tracking-[0.06em]
              uppercase text-zinc-400 mb-8 backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_8px_#22c55e] animate-pulse flex-shrink-0" />
              Cohort Program
            </div>
          </AnimateIn>
          <AnimateIn delay={100}>
            <h1 className="text-4xl md:text-[4.3rem] font-black tracking-[-0.04em] leading-[1.07] max-w-[680px] mx-auto mb-6">
              Document Your Business{' '}
              <span className="bg-gradient-to-br from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent">
                Brain in 5 Weeks.
              </span>
            </h1>
          </AnimateIn>
          <AnimateIn delay={200}>
            <p className="text-lg text-zinc-400 max-w-[590px] mx-auto mb-11 leading-[1.75]">
              The only program that takes you from founder-dependent to AI-augmented by
              documenting your 8 core business processes four levels deep — live, with a
              cohort of peers doing the same work.
            </p>
          </AnimateIn>
          <AnimateIn delay={300}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl hover:opacity-88 transition-opacity">
                Apply for the Next Cohort
              </button>
              <Link href="/teams"
                className="bg-transparent text-white border border-white/22 font-semibold text-base px-7 py-3.5 rounded-xl hover:border-white/50 hover:bg-white/7 transition-all">
                For Teams Instead
              </Link>
            </div>
          </AnimateIn>
        </div>

        {/* Progress steps bar */}
        <div className="relative z-10 bg-white/6 border-t border-white/10 px-6 py-6">
          <div className="max-w-[680px] mx-auto flex items-center gap-0">
            {[
              { num: '1', label: 'Master Prompt\nFoundation', active: true },
              { num: '2', label: 'Assessment &\nTaxonomy',   active: false },
              { num: '3', label: 'Documentation\nSprint',    active: false },
              { num: '4', label: 'AI Integration\nHandoff',  active: false },
            ].map((step, i) => (
              <div key={step.num} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-2 flex-1">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[0.8rem] font-bold transition-colors
                    ${step.active ? 'bg-blue-600 text-white' : 'bg-zinc-800 text-zinc-400'}`}>
                    {step.num}
                  </div>
                  <div className={`text-[0.68rem] font-semibold text-center leading-snug
                    ${step.active ? 'text-blue-400' : 'text-zinc-600'}`}
                    style={{ whiteSpace: 'pre-line' }}>
                    {step.label}
                  </div>
                </div>
                {i < 3 && <div className="h-px bg-zinc-800 flex-1 max-w-[40px] mb-6" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY AI TRAINING HASN'T CREATED TRANSFORMATION ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Problem</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight leading-tight mb-14">
              Why AI Training Hasn't Created{' '}
              <span className="text-blue-600">Transformation</span>
            </h2>
          </AnimateIn>
          <div className="grid md:grid-cols-2 gap-14 items-start">
            <AnimateIn direction="left">
              <p className="text-zinc-600 leading-[1.75] mb-4">
                You've been through the AI courses. You've watched the tutorials. You've
                experimented with the tools. But your business hasn't transformed — because
                none of it addressed the real problem.
              </p>
              <p className="text-zinc-600 leading-[1.75] mb-4">
                The issue isn't the AI. The issue is that AI has nothing to work with. No
                documented processes. No context. No systematic foundation. Every prompt
                starts from zero because your business knowledge lives in your head — not
                in a system.
              </p>
              <p className="text-zinc-600 leading-[1.75]">
                EMPOWER addresses this prerequisite problem first. Documentation before
                augmentation. Foundation before AI.
              </p>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-6">
                <p className="text-xs font-bold tracking-[0.1em] uppercase text-zinc-500 mb-4">
                  Why Most AI Adoption Fails
                </p>
                <div className="space-y-3">
                  {[
                    'Using AI tools without a documented foundation',
                    'Every prompt starting from zero — no shared context',
                    'Tribal knowledge locked in founders and key people',
                    'AI outputs inconsistent because inputs are inconsistent',
                    'No system for capturing and scaling what works',
                  ].map(item => (
                    <div key={item} className="flex items-start gap-2.5 text-sm text-zinc-600">
                      <span className="text-red-500 font-bold flex-shrink-0 mt-0.5">✗</span>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── QUOTE ── */}
      <div className="bg-zinc-50 border-t border-b border-zinc-200 py-12 px-6">
        <div className="max-w-[680px] mx-auto text-center">
          <AnimateIn>
            <p className="text-xl md:text-2xl font-bold tracking-tight leading-snug text-zinc-900">
              "We won't get you out of business. But a competitor who documents their processes and then applies AI might."
            </p>
          </AnimateIn>
        </div>
      </div>

      {/* ── DOCUMENT FIRST TRANSFORM SECOND ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Solution</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">
              <span className="text-blue-600">Document First,</span> Transform Second
            </h2>
            <p className="text-zinc-600 max-w-[600px] mx-auto mt-3 leading-relaxed">
              Most AI programs teach you to use tools. EMPOWER teaches you to build the
              foundation that makes every tool you'll ever use dramatically more effective.
            </p>
          </AnimateIn>
          <div className="grid md:grid-cols-2 gap-5">
            <AnimateIn direction="left">
              <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-7">
                <p className="text-xs font-bold tracking-[0.08em] uppercase text-red-500 mb-4">Without Foundation</p>
                <div className="space-y-2.5">
                  {['AI gives generic outputs because it has no context',
                    'Every team member prompts differently',
                    'Knowledge stays in founders\' heads',
                    'Can\'t delegate because nothing is documented',
                    'AI adoption stays at the experiment phase'].map(item => (
                    <div key={item} className="flex items-start gap-2 text-sm text-zinc-600 bg-red-50 rounded-lg px-3 py-2">
                      <span className="text-red-500 font-bold flex-shrink-0">✗</span>{item}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="bg-green-50 border border-green-200 rounded-2xl p-7">
                <p className="text-xs font-bold tracking-[0.08em] uppercase text-green-600 mb-4">With EMPOWER Foundation</p>
                <div className="space-y-2.5">
                  {['AI outputs are specific, on-brand, and accurate',
                    'Every team member has the same context',
                    'Knowledge lives in documented systems',
                    'Delegation becomes straightforward',
                    'AI transformation becomes achievable'].map(item => (
                    <div key={item} className="flex items-start gap-2 text-sm text-green-800 bg-green-100/60 rounded-lg px-3 py-2">
                      <span className="text-green-600 font-bold flex-shrink-0">✓</span>{item}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── FOUNDER BOTTLENECK ── */}
      <section className="bg-zinc-950 text-white py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <div className="grid md:grid-cols-2 gap-14 items-start">
            <AnimateIn direction="left">
              <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-400 mb-3">The Core Problem</p>
              <h2 className="text-3xl font-extrabold tracking-tight text-white mb-5 leading-snug">
                The Founder Bottleneck:<br />What AI Can't Fix Alone
              </h2>
              <p className="text-zinc-400 leading-[1.75] mb-4">
                The knowledge that runs your business lives in your head and the heads of a few
                key people. Your processes aren't written down. Your workflows aren't mapped.
              </p>
              <p className="text-zinc-400 leading-[1.75] mb-4">
                This isn't an AI problem. No amount of better prompts will extract that
                knowledge and turn it into a scalable system. That requires deliberate
                documentation work — exactly what EMPOWER is built to do.
              </p>
              <p className="text-zinc-400 leading-[1.75]">
                AI amplifies what's already documented. It cannot replace documentation
                that doesn't exist.
              </p>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="space-y-3">
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
                  <p className="text-xs font-bold tracking-[0.08em] uppercase text-zinc-600 mb-3">Current State — Most Businesses</p>
                  <div className="space-y-2">
                    {['Core processes undocumented','AI context missing or inconsistent',
                      'Founder is single point of failure','Knowledge transfer takes months or never happens'].map(i => (
                      <div key={i} className="flex items-center gap-2 text-sm text-zinc-500">
                        <span className="text-red-500">✗</span>{i}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-[#0a180a] border border-[#1a3a1a] rounded-xl p-5">
                  <p className="text-xs font-bold tracking-[0.08em] uppercase text-green-500 mb-3">After EMPOWER</p>
                  <div className="space-y-2">
                    {['8 core processes documented 4 levels deep','Master Prompt built with full business context',
                      'AI outputs that are specific and on-brand','Business knowledge captured and scalable'].map(i => (
                      <div key={i} className="flex items-center gap-2 text-sm text-green-300">
                        <span className="text-green-500">✓</span>{i}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── TWO PILLARS ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Methodology</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">
              The Two Pillars of{' '}
              <span className="text-blue-600">Documented</span> Transformation
            </h2>
            <p className="text-zinc-600 max-w-[600px] mx-auto mt-3">
              Two complementary systems that work together to build your documented business brain.
            </p>
          </AnimateIn>
          <div className="grid md:grid-cols-2 gap-7">
            {[
              {
                bg: 'linear-gradient(145deg,#1a1a2e,#0d0d1a)',
                visual: (
                  <div className="flex items-center justify-center h-full">
                    <div className="flex w-36 h-44 drop-shadow-2xl">
                      <div className="w-5 bg-blue-700 rounded-l" />
                      <div className="flex-1 bg-gradient-to-br from-blue-600 to-blue-800 rounded-r p-5 flex flex-col justify-end">
                        <p className="text-[0.55rem] font-bold tracking-widest uppercase text-blue-200/60 mb-2">MASTER PROMPT</p>
                        <p className="text-[0.9rem] font-black text-white leading-tight">Protect That.<br/>Build Everything.</p>
                      </div>
                    </div>
                  </div>
                ),
                title: 'The Master Prompt Method',
                desc: 'A structured process for extracting and documenting your Business DNA — your ICP, voice, pricing, competitive positioning, and strategic context — into a reusable AI context engine.',
              },
              {
                bg: 'linear-gradient(145deg,#0d1526,#080e1c)',
                visual: (
                  <div className="flex items-center justify-center h-full">
                    <div>
                      <p className="text-[0.65rem] font-bold tracking-widest uppercase text-blue-400 mb-3 text-center">THE EMPOWER OS</p>
                      <div className="grid grid-cols-4 gap-1.5 mb-1.5">
                        {['E','M','P','O'].map(l => (
                          <div key={l} className="bg-[#1a2540] rounded-lg p-2.5 text-[0.7rem] font-black text-zinc-100 text-center">{l}</div>
                        ))}
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {['W','E','R'].map(l => (
                          <div key={l} className="bg-[#1a2540] rounded-lg p-2.5 text-[0.7rem] font-black text-zinc-100 text-center">{l}</div>
                        ))}
                      </div>
                    </div>
                  </div>
                ),
                title: 'The EMPOWER OS Framework',
                desc: 'A seven-pillar assessment framework for identifying which of your 8 core business processes to document first — using value driver scoring across all seven pillars.',
              },
            ].map(pillar => (
              <AnimateIn key={pillar.title} direction={pillar.title.includes('Master') ? 'left' : 'right'}>
                <div className="border border-zinc-200 rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-1 transition-all">
                  <div className="h-60 p-8" style={{ background: pillar.bg }}>
                    {pillar.visual}
                  </div>
                  <div className="p-6">
                    <h3 className="font-bold text-[1.1rem] mb-2.5 tracking-tight">{pillar.title}</h3>
                    <p className="text-sm text-zinc-600 leading-[1.7]">{pillar.desc}</p>
                  </div>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── FROM ASSESSMENT TO AUGMENTATION ── */}
      <section className="bg-zinc-950 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-400 mb-3">The Full Program</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight text-white">
              From Assessment to Documentation<br />to{' '}
              <span className="text-blue-400">Augmentation</span>
            </h2>
          </AnimateIn>
          <div className="grid md:grid-cols-2 gap-5">
            {[
              { label: 'What we\'re doing', title: 'Assessment, Tools and Framework',
                items: ['The Thinking Four-Level Documentation Framework','The Thinking of Family of AI Tools and Platforms','The Four Levels of Business Documentation','Building Your EMPOWER OS Assessment Score'] },
              { label: 'What we\'re building', title: 'Document Foundation (Four Level Framework)',
                items: ['Profiling Stories and Core Business Narrative','Business DNA Master Prompt (Full Context)','Customer Flow Documentation — 4 levels deep','Money Flow Documentation — 4 levels deep','People Flow Documentation — 4 levels deep'] },
              { label: 'What we\'re building', title: 'AI-Augmented Business Systems',
                items: ['Bundled AI tools connected to documented processes','Business operations — automated and AI-monitored','Retention & Loyalty systems built on documentation','Revenue Age — AI-augmented growth infrastructure','Repeat Market systems — scalable without founder'] },
              { label: 'Integration', title: 'Capability Integration',
                items: ['Bundled 4 Integration options per process area','Strategic Alignment session with AI governance','Business ops automation — decisions to AI','Retention & Loyalty — AI-managed touchpoints'] },
            ].map((col, i) => (
              <AnimateIn key={col.title} direction={i % 2 === 0 ? 'left' : 'right'}>
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-7">
                  <p className="text-xs font-bold tracking-[0.1em] uppercase text-zinc-600 mb-2">{col.label}</p>
                  <h3 className="font-bold text-white mb-4 leading-snug">{col.title}</h3>
                  <div className="space-y-2">
                    {col.items.map(item => (
                      <div key={item} className="flex items-start gap-2 text-sm text-zinc-500">
                        <span className="text-blue-500 flex-shrink-0">→</span>{item}
                      </div>
                    ))}
                  </div>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHAT YOU ACTUALLY LEAVE WITH ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Deliverables</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">
              What You Actually <span className="text-blue-600">Leave With</span>
            </h2>
          </AnimateIn>

          <p className="text-xs font-bold tracking-[0.12em] uppercase text-zinc-500 mb-5">Tangible Documentation Deliverables</p>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 mb-14">
            {[
              { icon: '📄', title: 'Master Prompt Document',       desc: 'Your complete Business DNA in a reusable AI context engine. Every prompt, every team member, every AI tool — fed from the same documented foundation.' },
              { icon: '🗺',  title: 'Business Process Map',        desc: 'A visual map of your 8 core processes — Customer Flow, Money Flow, and People Flow — showing how they connect and where documentation gaps exist.' },
              { icon: '📋', title: 'Business Process Documentation', desc: 'Your core processes documented four levels deep — from high-level Core Process maps down to the daily Forms and Templates your team executes against.' },
              { icon: '🎯', title: 'EMPOWER OS Score Report',      desc: 'Your scored assessment across all seven EMPOWER value drivers — a prioritized roadmap showing which processes to document next and why.' },
              { icon: '⚡', title: 'Integration Roadmap',          desc: 'A blueprint for connecting your documented processes to AI tools, automation platforms, and the augmentation opportunities available to your business.' },
              { icon: '👥', title: 'Community Access',             desc: 'Two months of cohort community access — peer accountability, process reviews, live Q&A with the EMPOWER team, and a library of templates.' },
            ].map((d, i) => (
              <AnimateIn key={d.title} delay={(i % 3 * 100) as 0|100|200}>
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-6
                  hover:shadow-lg hover:-translate-y-0.5 transition-all">
                  <div className="text-2xl mb-3">{d.icon}</div>
                  <h4 className="font-bold text-sm mb-2 tracking-tight">{d.title}</h4>
                  <p className="text-xs text-zinc-600 leading-[1.65]">{d.desc}</p>
                </div>
              </AnimateIn>
            ))}
          </div>

          <p className="text-xs font-bold tracking-[0.12em] uppercase text-zinc-500 mb-5">Capability Gains</p>
          <div className="grid md:grid-cols-2 gap-4 mb-14">
            {[
              { title: 'Strategic Thinking Upgrade', desc: 'You\'ll understand your business at a systems level — seeing the processes, the flows, and the leverage points you couldn\'t see before.' },
              { title: 'AI Prompting Mastery',        desc: 'With a documented foundation, every AI interaction becomes dramatically more effective. Your prompts have context. Your outputs have consistency.' },
              { title: 'Delegation Capability',       desc: 'Documented processes are delegatable processes. You\'ll leave with the foundation to remove yourself from decisions that currently require your presence.' },
              { title: 'Scaling Without Chaos',       desc: 'Growth without documentation creates chaos. EMPOWER gives you the foundation to scale cleanly — adding people and AI without adding confusion.' },
            ].map((g, i) => (
              <AnimateIn key={g.title} delay={(i % 2 * 100) as 0|100}>
                <div className="flex items-start gap-3 bg-zinc-50 border border-zinc-200 rounded-xl p-5">
                  <span className="text-blue-600 font-bold text-lg flex-shrink-0">→</span>
                  <div>
                    <strong className="block text-sm font-bold mb-1">{g.title}</strong>
                    <p className="text-xs text-zinc-600 leading-[1.65]">{g.desc}</p>
                  </div>
                </div>
              </AnimateIn>
            ))}
          </div>

          {/* IS / IS NOT */}
          <div className="grid md:grid-cols-2 gap-5">
            <AnimateIn direction="left">
              <div className="bg-green-50 border border-green-200 rounded-2xl p-7">
                <h3 className="text-[1.1rem] font-extrabold mb-5">
                  What This <span className="text-green-600">IS</span>
                </h3>
                <div className="space-y-2.5">
                  {['Deliberate documentation work done live, in a cohort',
                    'Structured methodology for extracting and capturing business knowledge',
                    'A foundation-building program — prerequisite to AI transformation',
                    'Real deliverables: documents, maps, frameworks you keep forever',
                    'Peer accountability with founders doing the same work'].map(i => (
                    <div key={i} className="flex items-start gap-2 text-sm text-green-800 bg-green-100/60 rounded-lg px-3 py-2">
                      <span className="text-green-600 font-bold flex-shrink-0">✓</span>{i}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="bg-red-50 border border-red-200 rounded-2xl p-7">
                <h3 className="text-[1.1rem] font-extrabold mb-5">
                  What This is <span className="text-red-600">NOT</span>
                </h3>
                <div className="space-y-2.5">
                  {['An AI tools course or prompt engineering training',
                    'A passive content library you watch at your own pace',
                    'A consulting engagement where someone else does the work',
                    'A certification program with no real-world output',
                    'A quick fix — this is deliberate, structured transformation work'].map(i => (
                    <div key={i} className="flex items-start gap-2 text-sm text-red-800 bg-red-100/60 rounded-lg px-3 py-2">
                      <span className="text-red-600 font-bold flex-shrink-0">✕</span>{i}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── BUILT BY OPERATORS ── */}
      <section className="bg-zinc-950 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-400 mb-3">
              Built By Operators Who <span className="text-blue-400">Solved</span> This Problem First
            </p>
            <p className="text-zinc-400 max-w-[600px] mx-auto leading-relaxed">
              The EMPOWER framework wasn't designed by academics or consultants. It was built
              by operators who faced the same problem — and documented their way out of it.
            </p>
          </AnimateIn>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { init: '👤', name: 'Hayden Miyamoto', role: 'Founder, EMPOWER Labs',
                bg: 'linear-gradient(145deg,#1e293b,#0f172a)',
                bio: 'Manages a portfolio of 30+ active businesses. Built the EMPOWER OS after watching AI investments fail across his portfolio — always due to missing documentation, never due to missing tools.' },
              { init: '👤', name: 'Josh Collins', role: 'Co-Creator, EMPOWER Labs',
                bg: 'linear-gradient(145deg,#1a2e1a,#0f1a0f)',
                bio: 'Operator and documentation systems architect. Co-built the EMPOWER methodology from real business transformation work — not theory. Specializes in translating complex operations into AI-ready documentation frameworks.' },
            ].map(op => (
              <AnimateIn key={op.name} direction={op.name.includes('Hayden') ? 'left' : 'right'}>
                <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-7 text-center">
                  <div className="w-20 h-20 rounded-full flex items-center justify-center text-4xl mx-auto mb-4"
                    style={{ background: op.bg }}>
                    {op.init}
                  </div>
                  <h3 className="font-bold text-white text-lg mb-1">{op.name}</h3>
                  <p className="text-xs text-zinc-600 mb-4">{op.role}</p>
                  <p className="text-sm text-zinc-500 leading-[1.7]">{op.bio}</p>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── RESULTS ── */}
      <section className="bg-zinc-50 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">Proof</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">Results, Not Theory.</h2>
          </AnimateIn>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
            {[
              { val: '178',   label: 'Participants who have completed the EMPOWER program' },
              { val: '106',   label: 'Businesses with documented processes across 3+ departments' },
              { val: '75.5%', label: 'Of participants report measurable AI output improvement' },
              { val: '60',    label: 'Average days from program start to first AI-augmented process live' },
            ].map((s, i) => (
              <AnimateIn key={s.val} delay={(i * 100) as 0|100|200|300}>
                <div className="bg-white border border-zinc-200 rounded-2xl p-7 text-center">
                  <div className="text-[2.4rem] font-black tracking-[-0.04em] leading-none mb-2">{s.val}</div>
                  <div className="text-xs text-zinc-600 leading-snug">{s.label}</div>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <div className="bg-zinc-950 text-white py-24 px-6 text-center">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight text-white max-w-[600px] mx-auto mb-4">
              Ready to Document Your Business Brain?
            </h2>
            <p className="text-zinc-400 max-w-[520px] mx-auto mb-11 leading-relaxed">
              Applications are reviewed on a rolling basis. Spots are limited per cohort to
              ensure quality of work and peer accountability.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl hover:opacity-88 transition-opacity">
                Apply for the Next Cohort
              </button>
              <Link href="/teams"
                className="bg-transparent text-white border border-white/22 font-semibold text-base px-7 py-3.5 rounded-xl hover:border-white/50 hover:bg-white/7 transition-all">
                For Teams Instead
              </Link>
            </div>
            <div className="flex items-center justify-center gap-4 mt-6 text-xs text-zinc-600 flex-wrap">
              <span>Risk-Free 7-Day Refund</span><span>•</span>
              <span>Live cohort sessions</span><span>•</span>
              <span>Real deliverables</span>
            </div>
          </AnimateIn>
        </div>
      </div>

      <Newsletter source="cohort" />
      <Footer />
    </>
  )
}
