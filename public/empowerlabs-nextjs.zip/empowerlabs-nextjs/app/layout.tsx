import type { Metadata } from 'next'
import './globals.css'
import Nav from '@/components/Nav'

export const metadata: Metadata = {
  title: 'EMPOWER: Document Your Business Brain Before AI Transformation',
  description:
    'Stop using AI for random tasks. EMPOWER helps you document processes, build your Master Prompt, and create the foundation for AI transformation.',
  openGraph: {
    title: 'EMPOWER: Document Your Business Brain Before AI Transformation',
    description:
      'Stop using AI for random tasks. EMPOWER helps you document processes, build your Master Prompt, and create the foundation for AI transformation.',
    url: process.env.NEXT_PUBLIC_SITE_URL,
    siteName: 'EMPOWER Labs',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'EMPOWER Labs',
    description: 'The Business Operating System for Scaling',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-white text-zinc-900 antialiased overflow-x-hidden">
        {/* Announce bar */}
        <div className="bg-zinc-950 text-white text-center text-sm font-medium py-2.5 px-5 tracking-wide">
          Application Open for the Next Cohort &nbsp;·&nbsp;{' '}
          <a href="/cohort" className="underline underline-offset-2 opacity-75 hover:opacity-100 transition-opacity">
            Apply Now →
          </a>
        </div>

        <Nav />

        <main id="main-content">{children}</main>
      </body>
    </html>
  )
}
