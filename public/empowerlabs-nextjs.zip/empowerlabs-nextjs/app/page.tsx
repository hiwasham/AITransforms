import Link from 'next/link'
import Ticker from '@/components/Ticker'
import EmperorCards from '@/components/EmperorCards'
import Newsletter from '@/components/Newsletter'
import Footer from '@/components/Footer'
import AnimateIn from '@/components/AnimateIn'
import { getPosts, formatWPDate, stripHtml } from '@/lib/wordpress'

// This is a Server Component — runs on the server, fetches WP posts at build/request time
export default async function HomePage() {
  // Fetch latest blog posts from WordPress (shows at bottom of page)
  const wpPosts = await getPosts({ perPage: 3 }).catch(() => [])

  return (
    <>
      {/* ── HERO ── */}
      <section className="bg-zinc-950 text-white text-center relative overflow-hidden py-28 pb-24">
        {/* Glow */}
        <div className="absolute inset-0 animate-glow pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 85% 65% at 50% -5%, rgba(37,99,235,.42) 0%, transparent 68%)' }} />

        <div className="relative z-10 px-6">
          <AnimateIn>
            <div className="inline-flex items-center gap-2 bg-white/7 border border-white/13
              rounded-full px-4 py-1.5 text-[0.76rem] font-semibold tracking-[0.06em]
              uppercase text-zinc-400 mb-8 backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_8px_#22c55e] animate-pulse flex-shrink-0" />
              Application Open for the Next Cohort
            </div>
          </AnimateIn>

          <AnimateIn delay={100}>
            <h1 className="text-4xl md:text-[4.3rem] font-black tracking-[-0.04em] leading-[1.07]
              max-w-[820px] mx-auto mb-6">
              Build Your Business Brain{' '}
              <span className="bg-gradient-to-br from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent">
                Before AI Transformation
              </span>
            </h1>
          </AnimateIn>

          <AnimateIn delay={200}>
            <p className="text-lg text-zinc-400 max-w-[590px] mx-auto mb-11 leading-[1.75]">
              AI can't augment what isn't documented. EMPOWER creates the process foundation
              that makes AI adoption actually work—whether you use established operating systems,
              well-known business frameworks, or build from scratch.
            </p>
          </AnimateIn>

          <AnimateIn delay={300}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/cohort"
                className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl
                  hover:opacity-88 hover:-translate-y-0.5 transition-all duration-150">
                Explore Live Cohort
              </Link>
              <Link href="/teams"
                className="bg-transparent text-white border border-white/22 font-semibold
                  text-base px-7 py-3.5 rounded-xl hover:border-white/50
                  hover:bg-white/7 hover:-translate-y-0.5 transition-all duration-150">
                For Teams
              </Link>
            </div>
          </AnimateIn>
        </div>
      </section>

      <Ticker />

      {/* ── PROBLEM ── */}
      <section className="bg-zinc-950 text-white py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-400 mb-3">
              The Problem
            </p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight leading-tight mb-14 max-w-[600px]">
              Why AI Training Hasn't Created Transformation
            </h2>
          </AnimateIn>

          <div className="grid md:grid-cols-2 gap-14 items-start">
            <AnimateIn direction="left">
              <p className="text-zinc-400 leading-[1.75] mb-4">
                You've spent years building expertise. But transformation hasn't happened because{' '}
                <strong className="text-white">every time you use AI, you start from scratch.</strong>{' '}
                The AI doesn't know your pricing, your team structure, your strategic goals,
                or your documented processes.
              </p>
              <h3 className="text-2xl font-extrabold tracking-tight text-white mb-3 mt-8">
                The Founder Bottleneck:<br />What AI Can't Fix Alone
              </h3>
              <p className="text-zinc-400 leading-[1.75] mb-3">
                The knowledge that runs your business lives in your head and the heads of a few
                key people. Your processes aren't written down. Your workflows aren't mapped.
              </p>
              <p className="text-zinc-400 leading-[1.75]">
                This is the <strong className="text-white">founder bottleneck</strong>. No
                amount of better prompts will fix it.
              </p>
              <div className="border-l-[3px] border-blue-600 pl-5 mt-7 bg-blue-600/8 py-4 pr-4 rounded-r-xl">
                <p className="text-zinc-400 italic leading-[1.7] text-sm">
                  "The EMPOWER framework changes that—transforming how you document,
                  systematize, and AI-enable every part of your business."
                </p>
              </div>
            </AnimateIn>

            {/* Terminal */}
            <AnimateIn direction="right">
              <div className="bg-[#0d1117] border border-zinc-800 rounded-2xl overflow-hidden shadow-[0_24px_64px_rgba(0,0,0,0.5)]">
                <div className="bg-[#161b22] px-4 py-3 flex items-center gap-2 border-b border-zinc-800">
                  <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
                  <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
                  <span className="w-3 h-3 rounded-full bg-[#28c840]" />
                  <span className="flex-1 text-center text-xs text-zinc-600 font-mono">System Diagnostics</span>
                </div>
                <div className="p-6 font-mono text-sm">
                  <p className="text-xs text-zinc-600 uppercase tracking-widest mb-3">Status Report</p>
                  <div className="inline-block bg-red-500/14 text-red-400 border border-red-500/24
                    text-xs font-bold px-3 py-1 rounded mb-5">
                    ⚠ Critical Disconnect
                  </div>
                  {[
                    'No centralized knowledge base',
                    'Processes live in people\'s heads',
                    'Data silos between departments',
                    'AI outputs are inconsistent & generic',
                  ].map(item => (
                    <div key={item} className="flex items-center gap-2.5 text-zinc-500 mb-2 text-[0.8rem]">
                      <span className="text-red-500">✗</span>{item}
                    </div>
                  ))}
                  <hr className="border-zinc-800 my-4" />
                  <p className="text-red-500 text-[0.78rem] tracking-widest">
                    ERROR_CODE_404_CONTEXT
                    <span className="inline-block w-2 h-3.5 bg-green-400 ml-0.5 align-bottom cursor-blink" />
                  </p>
                  <hr className="border-zinc-800 my-4" />
                  <p className="text-amber-500 text-[0.78rem] tracking-widest">ACTION REQUIRED</p>
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <div className="bg-zinc-950 py-14 px-6 border-t border-zinc-900">
        <div className="max-w-[880px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { val: '65%', label: 'Use established operating systems' },
            { val: '30+', label: 'Active businesses managed by the founder' },
            { val: '8',   label: 'Core processes across Customer, Money & People Flow' },
            { val: '4',   label: 'Documentation levels for complete AI readiness' },
          ].map(stat => (
            <AnimateIn key={stat.val}>
              <div className="text-[2.4rem] font-black tracking-[-0.04em] text-white leading-none">
                {stat.val}
              </div>
              <div className="text-[0.8rem] text-zinc-600 mt-1.5 font-medium leading-snug">
                {stat.label}
              </div>
            </AnimateIn>
          ))}
        </div>
      </div>

      {/* ── FRAMEWORK ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">System Architecture</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight leading-tight mb-4">
              The EMPOWER Framework: What Must Exist First
            </h2>
            <p className="text-zinc-600 max-w-[600px] mx-auto mb-14 leading-relaxed">
              Before AI can transform your business, you need three things documented:
            </p>
          </AnimateIn>

          <div className="grid md:grid-cols-3 gap-5 mb-14">
            {[
              { icon: '🗺', tag: 'Infrastructure', title: 'A complete map of your processes',
                desc: 'Not whatever happens to be documented. The 8 core processes across Customer Flow, Money Flow, and People Flow.' },
              { icon: '📋', tag: 'Hierarchy', title: 'Documentation at four levels',
                desc: 'Strategic overview, functional breakdown, step-by-step guides, and daily templates. Not just high-level or overly detailed.' },
              { icon: '🎯', tag: 'Strategy', title: 'Clarity on what matters',
                desc: 'Not all processes affect value equally. You need to know which ones to fix first to maximize enterprise value.' },
            ].map((card, i) => (
              <AnimateIn key={card.tag} delay={(i * 100) as 0|100|200}>
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-7
                  hover:shadow-[0_8px_32px_rgba(0,0,0,0.09)] hover:-translate-y-1
                  hover:border-zinc-300 transition-all duration-250">
                  <div className="w-10 h-10 bg-zinc-950 rounded-xl flex items-center justify-center text-lg mb-4">
                    {card.icon}
                  </div>
                  <p className="text-[0.7rem] font-bold tracking-[0.1em] uppercase text-blue-600 mb-2">{card.tag}</p>
                  <h3 className="font-bold text-[1.05rem] mb-2.5 leading-snug">{card.title}</h3>
                  <p className="text-sm text-zinc-600 leading-[1.65]">{card.desc}</p>
                </div>
              </AnimateIn>
            ))}
          </div>

          <AnimateIn>
            <p className="text-sm text-zinc-600">
              EMPOWER is how we assess which processes to document first, using seven value drivers:
            </p>
          </AnimateIn>
        </div>
      </section>

      {/* ── EMPEROR CARDS ── */}
      <EmperorCards />

      {/* ── CHOOSE YOUR PATH ── */}
      <section id="path" className="bg-zinc-50 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight mb-3">
              Choose Your Path
            </h2>
            <p className="text-zinc-600">How do you want to build your operating framework?</p>
          </AnimateIn>

          <div className="grid md:grid-cols-2 gap-5">
            {/* Live Cohort — featured */}
            <AnimateIn direction="left">
              <div className="bg-zinc-950 text-white border border-zinc-950 rounded-2xl p-9 flex flex-col h-full">
                <p className="text-xs font-bold tracking-[0.1em] uppercase text-blue-400 mb-1.5">Live Cohort</p>
                <p className="text-sm text-zinc-500 mb-5">Founders, Execs & Managers</p>
                <h3 className="text-[1.35rem] font-extrabold tracking-tight mb-3.5 leading-snug">
                  The intensive program to document your business brain.
                </h3>
                <p className="text-sm text-zinc-400 leading-[1.72] mb-5 flex-1">
                  Move from founder-dependent to AI-augmented by documenting 8 core processes
                  four levels deep, building your Master Prompt, and creating the foundation
                  for AI transformation.
                </p>
                <ul className="space-y-2 mb-6">
                  {['Master Prompt Foundation (3 modules)','EMPOWER 101 (5-module sprint, live cohort)',
                    'Process taxonomy assessment','Four-level documentation framework',
                    'Value driver scoring','2-month community access'].map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-zinc-400">
                      <span className="text-blue-500 font-bold flex-shrink-0">—</span>{f}
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-zinc-600 italic mb-5">
                  Not training. Transformation work. You leave with documented processes and
                  clear priorities, not just certificates.
                </p>
                <Link href="/cohort"
                  className="block text-center bg-white text-zinc-950 font-bold text-sm
                    py-3.5 rounded-xl hover:opacity-88 hover:-translate-y-0.5 transition-all">
                  Explore Curriculum
                </Link>
              </div>
            </AnimateIn>

            {/* For Teams */}
            <AnimateIn direction="right">
              <div className="bg-white border border-zinc-200 rounded-2xl p-9 flex flex-col h-full
                hover:shadow-[0_16px_48px_rgba(0,0,0,0.1)] hover:border-zinc-300 transition-all">
                <p className="text-xs font-bold tracking-[0.1em] uppercase text-blue-600 mb-1.5">For Teams</p>
                <p className="text-sm text-zinc-500 mb-5">Companies with 10+ Staff</p>
                <h3 className="text-[1.35rem] font-extrabold tracking-tight mb-3.5 leading-snug">
                  Scale the EMPOWER methodology across your entire organization.
                </h3>
                <p className="text-sm text-zinc-600 leading-[1.72] mb-5 flex-1">
                  Install a unified documentation system, train your workforce on the Master
                  Prompt methodology, and eliminate the silos that keep AI adoption stuck.
                </p>
                <ul className="space-y-2 mb-6">
                  {['Executive strategy workshop','Team-wide EMPOWER 101 access',
                    'Centralized Master Context engine','Guided implementation rollout',
                    'Department-specific workflow training'].map(f => (
                    <li key={f} className="flex items-start gap-2 text-sm text-zinc-600">
                      <span className="text-blue-600 font-bold flex-shrink-0">—</span>{f}
                    </li>
                  ))}
                </ul>
                <p className="text-xs text-zinc-500 italic mb-5">
                  For organizations ready to move beyond individual AI experiments to
                  systematic transformation.
                </p>
                <Link href="/teams"
                  className="block text-center bg-zinc-950 text-white font-bold text-sm
                    py-3.5 rounded-xl hover:opacity-85 hover:-translate-y-0.5 transition-all">
                  View Team Roadmap
                </Link>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="bg-zinc-50 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">
              Voices of Transformation
            </h2>
            <p className="text-zinc-600 mt-2">
              See how leaders across industries are rebuilding their businesses with the EMPOWER framework.
            </p>
          </AnimateIn>

          <div className="grid md:grid-cols-2 gap-5">
            {[
              { init: 'A', name: 'Andreas Sander', role: 'Founder & CEO of KOSATEC', industry: 'Global Innovation', bg: '#1e3a5f',
                quote: '"The program is exceptional. It\'s not just a course – it\'s a transformation. The team at EMPOWER Labs are from another planet – world-class minds, perfectly structured, deeply strategic."' },
              { init: 'R', name: 'Rich Fettke', role: 'CEO, Real Wealth Realty', industry: 'Real Estate Investment', bg: '#1a3d2e',
                quote: '"It\'s like we have hired multiple experts with PhDs in finance, operations, marketing, positioning and technology...but have not had to increase our payroll."' },
              { init: 'D', name: 'Don Bury', role: 'Founder, Insurance Controls', industry: 'Construction & AI', bg: '#3d1a1a',
                quote: '"The concept of conducting threat assessments around competitors adopting AI has become a potent client-getter for consultants like me."' },
              { init: 'M', name: 'Michael DeCristofaro', role: 'Real Wealth Realty, Inc.', industry: 'Real Estate Finance', bg: '#1a2a3d',
                quote: '"This program doesn\'t just teach you systems — it completely rewires how you think about running your business."' },
            ].map((t, i) => (
              <AnimateIn key={t.name} delay={(i < 2 ? (i * 100) : ((i - 2) * 100)) as 0|100}>
                <div className="bg-white border border-zinc-200 rounded-2xl p-7
                  hover:shadow-[0_8px_32px_rgba(0,0,0,0.07)] hover:-translate-y-0.5 transition-all">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center
                      font-extrabold text-white text-base flex-shrink-0"
                      style={{ background: t.bg }}>
                      {t.init}
                    </div>
                    <div>
                      <div className="text-sm font-bold">
                        {t.name}
                        <span className="ml-2 text-[0.65rem] font-bold tracking-widest uppercase
                          bg-zinc-100 border border-zinc-200 text-zinc-500 px-2 py-0.5 rounded align-middle">
                          {t.industry}
                        </span>
                      </div>
                      <div className="text-xs text-zinc-500">{t.role}</div>
                    </div>
                  </div>
                  <blockquote className="text-sm text-zinc-600 leading-[1.78] italic">
                    {t.quote}
                  </blockquote>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── WORDPRESS BLOG POSTS (dynamic from WP REST API) ── */}
      {wpPosts.length > 0 && (
        <section className="py-24 px-6">
          <div className="max-w-[1100px] mx-auto">
            <AnimateIn className="flex items-center justify-between mb-10">
              <div>
                <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-1.5">From the Blog</p>
                <h2 className="text-2xl font-extrabold tracking-tight">Latest from WordPress</h2>
              </div>
              <a href="/blog" className="text-sm font-semibold text-blue-600 hover:underline">
                View all posts →
              </a>
            </AnimateIn>

            <div className="grid md:grid-cols-3 gap-5">
              {wpPosts.map((post, i) => {
                const image = post._embedded?.['wp:featuredmedia']?.[0]
                return (
                  <AnimateIn key={post.id} delay={(i * 100) as 0|100|200}>
                    <a href={`/blog/${post.slug}`}
                      className="block bg-white border border-zinc-200 rounded-2xl overflow-hidden
                        hover:shadow-[0_8px_28px_rgba(0,0,0,0.08)] hover:-translate-y-1 transition-all">
                      {image && (
                        <div className="aspect-[16/9] bg-zinc-100 overflow-hidden">
                          <img src={image.source_url} alt={image.alt_text || post.title.rendered}
                            className="w-full h-full object-cover" />
                        </div>
                      )}
                      <div className="p-5">
                        <p className="text-xs text-zinc-400 mb-2">{formatWPDate(post.date)}</p>
                        <h3 className="font-bold text-sm mb-2 leading-snug"
                          dangerouslySetInnerHTML={{ __html: post.title.rendered }} />
                        <p className="text-xs text-zinc-500 leading-relaxed line-clamp-2">
                          {stripHtml(post.excerpt.rendered)}
                        </p>
                      </div>
                    </a>
                  </AnimateIn>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* ── FOUNDER ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <div className="grid md:grid-cols-[1fr_1.45fr] gap-20 items-center">
            <AnimateIn direction="left">
              <div className="relative">
                <div className="aspect-[4/5] bg-gradient-to-br from-zinc-800 to-zinc-950
                  rounded-3xl flex items-center justify-center text-[6rem]">
                  👤
                </div>
                <div className="absolute -bottom-5 left-1/2 -translate-x-1/2
                  bg-white border border-zinc-200 rounded-full px-5 py-2.5
                  text-sm font-bold whitespace-nowrap shadow-lg">
                  30+ Acquisitions · Lifelong Student of Business
                </div>
              </div>
            </AnimateIn>
            <AnimateIn direction="right">
              <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">
                Built by an Operator, Not a Theorist.
              </p>
              <h2 className="text-3xl font-extrabold tracking-tight mb-5 leading-snug">
                Hayden Miyamoto manages a portfolio of 30+ active businesses. He built the
                EMPOWER OS to survive the chaos of scaling a 9-figure portfolio.
              </h2>
              <p className="text-zinc-600 leading-[1.78] mb-3.5">
                After seeing businesses invest in AI training programs and adoption platforms
                without results, Hayden realized the problem wasn't the tools or training.
                It was the missing foundation. Most businesses don't have their processes
                documented four levels deep. EMPOWER was built to solve that prerequisite
                problem first.
              </p>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <div className="bg-zinc-950 text-white py-24 px-6 text-center">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight text-white max-w-[720px] mx-auto mb-4">
              Stop Experimenting. Start Systematizing.
            </h2>
            <p className="text-zinc-400 max-w-[540px] mx-auto mb-11 leading-relaxed">
              The difference between businesses that transform and businesses that stall
              isn't better prompts or fancier tools. It's process depth.
              <br /><br />
              You can't augment what isn't documented.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link href="/cohort"
                className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl
                  hover:opacity-88 transition-opacity">
                Join Live Cohort
              </Link>
              <Link href="/teams"
                className="bg-transparent text-white border border-white/22 font-semibold
                  text-base px-7 py-3.5 rounded-xl hover:border-white/50 hover:bg-white/7 transition-all">
                Learn More About Teams
              </Link>
            </div>
            <div className="flex items-center justify-center gap-4 mt-6 flex-wrap">
              <span className="text-xs text-zinc-600">Risk-Free 7-Day Refund (Cohort)</span>
              <span className="text-zinc-700">•</span>
              <span className="text-xs text-zinc-600">Unified Team Systems (Teams)</span>
            </div>
          </AnimateIn>
        </div>
      </div>

      <Newsletter source="newsletter" />
      <Footer />
    </>
  )
}
