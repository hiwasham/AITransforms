import Link from 'next/link'
import Ticker from '@/components/Ticker'
import Newsletter from '@/components/Newsletter'
import Footer from '@/components/Footer'
import AnimateIn from '@/components/AnimateIn'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'For Teams | EMPOWER Labs',
  description: 'Scale the EMPOWER methodology across your entire workforce. Move from scattered AI experiments to systematic documentation.',
}

export default function TeamsPage() {
  return (
    <>
      {/* ── HERO ── */}
      <section className="bg-zinc-950 text-white text-center relative overflow-hidden py-28 pb-24">
        <div className="absolute inset-0 animate-glow pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 85% 65% at 50% -5%, rgba(139,92,246,.4) 0%, transparent 68%)' }} />
        <div className="relative z-10 px-6">
          <AnimateIn>
            <div className="inline-flex items-center gap-2 bg-white/7 border border-white/13
              rounded-full px-4 py-1.5 text-[0.76rem] font-semibold tracking-[0.06em]
              uppercase text-zinc-400 mb-8 backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-violet-400 shadow-[0_0_8px_#a78bfa] animate-pulse flex-shrink-0" />
              For Teams
            </div>
          </AnimateIn>
          <AnimateIn delay={100}>
            <h1 className="text-4xl md:text-[4.3rem] font-black tracking-[-0.04em] leading-[1.07] max-w-[820px] mx-auto mb-6">
              Document Your<br />Organization's Brain{' '}
              <span className="bg-gradient-to-br from-violet-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Before AI Transformation
              </span>
            </h1>
          </AnimateIn>
          <AnimateIn delay={200}>
            <p className="text-lg text-zinc-400 max-w-[590px] mx-auto mb-11 leading-[1.75]">
              Scale the EMPOWER methodology across your entire workforce. Move from scattered
              AI experiments to systematic documentation that makes AI adoption actually work.
            </p>
          </AnimateIn>
          <AnimateIn delay={300}>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl hover:opacity-88 transition-opacity">
                Enroll My Team
              </button>
              <button className="bg-transparent text-white border border-white/22 font-semibold text-base px-7 py-3.5 rounded-xl hover:border-white/50 hover:bg-white/7 transition-all">
                View Roadmap
              </button>
            </div>
          </AnimateIn>
        </div>
      </section>

      <Ticker />

      {/* ── WHY ENTERPRISE AI FAILS ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <div className="grid md:grid-cols-2 gap-14 items-start">
            <AnimateIn direction="left">
              <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Problem</p>
              <h2 className="text-3xl font-extrabold tracking-tight leading-tight mb-5">
                Why Enterprise AI Adoption Fails:{' '}
                <span className="text-blue-600">The Documentation Gap</span>
              </h2>
              <p className="text-zinc-600 leading-[1.75] mb-4">
                "The key reason something like AI in X is not working the way AI should work."
              </p>
              <p className="text-zinc-600 leading-[1.75] mb-4">
                This isn't an adoption problem. It's an <strong>infrastructure problem</strong>.
              </p>
              <p className="text-zinc-600 leading-[1.75] mb-4">
                Every department is running its own AI experiments. Some people are using it
                daily, others never. But the real problem isn't enthusiasm — it's that AI has
                nothing to work with. No documented processes. No shared context.
              </p>
              <p className="text-zinc-600 leading-[1.75]">
                Until your organization's knowledge is documented, AI adoption will stay stuck
                at the experimentation stage — impressive demos, no transformation.
              </p>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="bg-[#0d1117] border border-zinc-800 rounded-2xl overflow-hidden shadow-[0_24px_64px_rgba(0,0,0,0.5)]">
                <div className="bg-[#161b22] px-4 py-3 flex items-center gap-2 border-b border-zinc-800">
                  <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
                  <span className="w-3 h-3 rounded-full bg-[#febc2e]" />
                  <span className="w-3 h-3 rounded-full bg-[#28c840]" />
                  <span className="flex-1 text-center text-xs text-zinc-600 font-mono">Enterprise AI Audit</span>
                </div>
                <div className="p-6 font-mono text-sm">
                  <p className="text-xs text-zinc-600 uppercase tracking-widest mb-3">Organization Status</p>
                  <div className="inline-block bg-red-500/14 text-red-400 border border-red-500/24 text-xs font-bold px-3 py-1 rounded mb-5">
                    ⚠ Documentation Gap Detected
                  </div>
                  {['AI tools deployed — no documented context','Department silos preventing knowledge transfer',
                    'No unified Master Prompt or Business DNA','Tribal knowledge locked in individual heads'].map(i => (
                    <div key={i} className="flex items-center gap-2.5 text-zinc-500 mb-2 text-[0.8rem]">
                      <span className="text-red-500">✗</span>{i}
                    </div>
                  ))}
                  <hr className="border-zinc-800 my-4" />
                  <p className="text-red-500 text-[0.78rem] tracking-widest">ADOPTION_BLOCKED: Missing foundation layer</p>
                  <hr className="border-zinc-800 my-4" />
                  <p className="text-amber-500 text-[0.78rem] tracking-widest">RECOMMENDED: Install documentation system first</p>
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── EMPOWER FOR TEAMS METHODOLOGY ── */}
      <section className="bg-[#080e1c] py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-14">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-400 mb-3">
              The EMPOWER For Teams Methodology
            </p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight text-white mb-3">
              We don't just teach prompting. We install a{' '}
              <span className="text-blue-400">documentation system</span> built for scale.
            </h2>
            <p className="text-[#6b7a99] max-w-[600px] mx-auto leading-relaxed">
              We install a documentation system built for scale, security, and systematic AI
              adoption across your entire workforce.
            </p>
          </AnimateIn>

          {/* Stage 1 */}
          <AnimateIn>
            <div className="inline-flex items-center gap-2 bg-blue-500/12 border border-blue-500/25
              text-blue-400 text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full mb-5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
              Stage 1: Foundation & Alignment
            </div>
          </AnimateIn>
          <div className="grid md:grid-cols-3 gap-3 mb-10">
            {[
              { num: 'Phase 0',          title: 'Onboarding & Change Management',
                desc: 'Aligning leadership, setting expectations, and preparing your team for a documentation-first transformation. We handle the change management so you don\'t have to.' },
              { num: 'Phase Empower 101', title: 'EMPOWER 101',
                desc: 'Your entire team goes through the EMPOWER 101 sprint together. Everyone learns the same taxonomy, uses the same documentation language, and builds from a shared foundation.' },
              { num: 'Phase 2',           title: 'Strategic Alignment',
                desc: 'Map your highest-value processes using the EMPOWER value driver scoring system. Identify where documentation creates the most enterprise value before writing a single SOP.' },
            ].map((phase, i) => (
              <AnimateIn key={phase.num} delay={(i * 100) as 0|100|200}>
                <div className="bg-[#0d1526] border border-[#1a2540] rounded-2xl p-6 hover:border-[#2e4272] hover:-translate-y-1 transition-all">
                  <p className="text-xs font-bold tracking-[0.1em] uppercase text-blue-400 mb-2">{phase.num}</p>
                  <h3 className="font-bold text-[#e8eaf2] mb-3 leading-snug">{phase.title}</h3>
                  <p className="text-sm text-[#6b7a99] leading-[1.65]">{phase.desc}</p>
                </div>
              </AnimateIn>
            ))}
          </div>

          {/* Stage 2 */}
          <AnimateIn>
            <div className="inline-flex items-center gap-2 bg-blue-500/12 border border-blue-500/25
              text-blue-400 text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full mb-5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
              Stage 2: Implementation & Scale
            </div>
          </AnimateIn>
          <div className="grid md:grid-cols-3 gap-3">
            {[
              { num: 'Phase 3', title: 'AI-Powered Growth Engine',
                desc: 'Document and AI-augment your revenue processes. Lead scoring, automated outreach, CRM enrichment, and proposal generation — all built on your documented foundation.' },
              { num: 'Phase 4', title: 'AI-Driven Operations Core',
                desc: 'SOP execution, quality management, contract analysis, and workflow integration — systematized across departments with AI enforcement built in from day one.' },
              { num: 'Phase 5', title: 'AI-Augmented People System',
                desc: 'Recruiting, onboarding, performance reviews, and L&D pathways — all running on documented frameworks that AI can execute, monitor, and improve continuously.' },
            ].map((phase, i) => (
              <AnimateIn key={phase.num} delay={(i * 100) as 0|100|200}>
                <div className="bg-[#0d1526] border border-[#1a2540] rounded-2xl p-6 hover:border-[#2e4272] hover:-translate-y-1 transition-all">
                  <p className="text-xs font-bold tracking-[0.1em] uppercase text-blue-400 mb-2">{phase.num}</p>
                  <h3 className="font-bold text-[#e8eaf2] mb-3 leading-snug">{phase.title}</h3>
                  <p className="text-sm text-[#6b7a99] leading-[1.65]">{phase.desc}</p>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOR / NOT FOR ── */}
      <section className="bg-[#0d1117] py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <div className="grid md:grid-cols-2 gap-5">
            <AnimateIn direction="left">
              <div className="bg-[#0a1a0f] border border-[#1a3a20] rounded-2xl p-9">
                <h3 className="text-[1.35rem] font-extrabold text-white mb-6 leading-snug">
                  This Program Is <span className="text-green-400">For</span><br />Organizations That...
                </h3>
                <div className="space-y-3">
                  {['Have 10–45 employees with valuable tribal knowledge locked in a few key people',
                    'Have 2–3 people who are single points of failure for critical decisions or processes',
                    'Are running systems (EOS, Scaling Up, etc.) but missing the process documentation layer',
                    'Have invested in AI infrastructure but can\'t deploy it systematically across the team',
                    'Need knowledge capture at the highest levels before key people leave or scale breaks things'].map(i => (
                    <div key={i} className="flex items-start gap-3 text-sm text-green-300 bg-green-500/8 border border-green-500/15 rounded-xl px-4 py-3">
                      <span className="text-green-500 font-bold flex-shrink-0 mt-0.5">✓</span>{i}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
            <AnimateIn direction="right">
              <div className="bg-[#1a0a0a] border border-[#3a1a1a] rounded-2xl p-9">
                <h3 className="text-[1.35rem] font-extrabold text-white mb-6 leading-snug">
                  This Program Is <span className="text-red-400">NOT For</span><br />Organizations That...
                </h3>
                <div className="space-y-3">
                  {['Just want something finished in 2 weeks without real documentation work being done',
                    'Aren\'t creating a long-term relationship with their documentation and AI systems',
                    'Need just-in-time documentation without a systematic approach to knowledge capture',
                    'Have fewer than 5 employees without real process complexity that needs documenting',
                    'Have a team that isn\'t bought into the documentation-first approach to AI transformation'].map(i => (
                    <div key={i} className="flex items-start gap-3 text-sm text-red-300 bg-red-500/8 border border-red-500/15 rounded-xl px-4 py-3">
                      <span className="text-red-500 font-bold flex-shrink-0 mt-0.5">✕</span>{i}
                    </div>
                  ))}
                </div>
              </div>
            </AnimateIn>
          </div>
        </div>
      </section>

      {/* ── TRANSFORMATION ROADMAP ── */}
      <section className="bg-zinc-50 py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn className="text-center mb-16">
            <p className="text-xs font-bold tracking-[0.14em] uppercase text-blue-600 mb-3">The Transformation Roadmap</p>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">The Transformation Roadmap</h2>
            <p className="text-zinc-600 mt-3 max-w-[560px] mx-auto">
              An eight-week structured implementation that transforms AI adoption across your entire organization.
            </p>
          </AnimateIn>

          <div className="relative">
            {/* Center line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-zinc-200 -translate-x-1/2 hidden md:block" />

            <div className="space-y-10">
              {[
                { phase: 'Phase 0', title: 'Onboarding & Change Management', left: true,
                  desc: 'Executive alignment session. Team communication plan. Roles and responsibilities assigned. Documentation infrastructure set up. Change management protocol activated.' },
                { phase: 'Phase 1', title: 'EMPOWER 101', left: false,
                  desc: 'Full team completes the EMPOWER 101 sprint. Master Prompt Foundation built for the organization. Process taxonomy introduced. Value driver scoring completed.' },
                { phase: 'Phase 2', title: 'Strategic Alignment', left: true,
                  desc: 'EMPOWER value driver scoring across all seven pillars. Highest-leverage processes identified. Documentation priority map created. Department leads assigned.' },
                { phase: 'Phase 3', title: 'Growth Engine', left: false,
                  desc: 'Revenue processes documented four levels deep. Lead scoring, CRM enrichment, proposal generation, and automated outreach — all built on the documented foundation.' },
                { phase: 'Phase 4', title: 'Operations Core', left: true,
                  desc: 'Operational processes mapped and documented. SOP execution engine installed. Quality management framework deployed. Workflow integration connecting all documented systems.' },
                { phase: 'Phase 5', title: 'People System', left: false,
                  desc: 'HR processes documented and AI-augmented. Recruiting aligned to documented role requirements. Onboarding running automatically. Performance reviews using documented frameworks.' },
              ].map(step => (
                <AnimateIn key={step.title} direction={step.left ? 'left' : 'right'}>
                  <div className={`flex items-center gap-6 ${step.left ? 'flex-row' : 'flex-row-reverse'} md:flex-row`}>
                    <div className={`flex-1 ${step.left ? 'md:text-right' : 'md:ml-auto'}`}>
                      <div className={`bg-white border border-zinc-200 rounded-2xl p-7 hover:shadow-lg hover:-translate-y-0.5 transition-all ${step.left ? '' : 'md:ml-auto'}`}>
                        <p className="text-xs font-bold tracking-[0.1em] uppercase text-blue-600 mb-2">{step.phase}</p>
                        <h3 className="font-bold text-[1.05rem] mb-2.5 tracking-tight">{step.title}</h3>
                        <p className="text-sm text-zinc-600 leading-[1.65]">{step.desc}</p>
                      </div>
                    </div>
                    {/* Dot */}
                    <div className="hidden md:flex flex-shrink-0 w-4 h-4 bg-blue-600 rounded-full border-[3px] border-white shadow-[0_0_0_3px_#2563eb] z-10" />
                    <div className="flex-1 hidden md:block" />
                  </div>
                </AnimateIn>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── DEPARTMENTS CAN AUGMENT ── */}
      <section className="py-24 px-6">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl px-5 py-4 mb-10">
              <span className="text-amber-500 text-lg flex-shrink-0">⚠</span>
              <p className="text-sm text-amber-800 leading-relaxed">
                <strong>Important:</strong> once processes are documented four levels deep and your Master Prompt
                is built, AI agents can execute, monitor, and improve each module autonomously — without
                founder involvement in routine decisions.
              </p>
            </div>
          </AnimateIn>
          <AnimateIn className="text-center mb-10">
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight">
              Once Processes Are Documented,<br />Departments Can Augment
            </h2>
            <p className="text-zinc-600 mt-3">
              Each department unlocks a set of AI modules once their core processes are documented four levels deep.
            </p>
          </AnimateIn>
          <div className="grid md:grid-cols-3 gap-5">
            {[
              { tag: 'Growth Engine', sub: 'Revenue & Market Expansion', color: '#1D9E75',
                items: ['Lead scoring (based on qualification criteria)','Automated outreach (using brand voice)','CRM enrichment (connected to sales process)','Proposal generation (leveraging service offerings)'] },
              { tag: 'Operations Core', sub: 'Efficiency & Governance', color: '#185FA5',
                items: ['SOP execution (following documented procedures)','Contract analysis (against documented standards)','Workflow integration (between documented systems)','Quality management (based on documented requirements)'] },
              { tag: 'People OS', sub: 'Talent & Culture', color: '#534AB7',
                items: ['Recruiting (aligned to documented role requirements)','Onboarding (following documented workflows)','Performance reviews (using documented frameworks)','L&D pathways (supporting documented skills)'] },
            ].map((dept, i) => (
              <AnimateIn key={dept.tag} delay={(i * 100) as 0|100|200}>
                <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-6 hover:shadow-lg hover:-translate-y-0.5 transition-all">
                  <p className="text-sm font-bold mb-1" style={{ color: dept.color }}>{dept.tag}</p>
                  <p className="text-xs text-zinc-500 font-medium uppercase tracking-wide mb-4">{dept.sub}</p>
                  <div className="space-y-2">
                    {dept.items.map(item => (
                      <div key={item} className="flex items-start gap-2 text-sm text-zinc-600">
                        <span className="text-zinc-400 flex-shrink-0">—</span>{item}
                      </div>
                    ))}
                  </div>
                </div>
              </AnimateIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <div className="bg-zinc-950 text-white py-24 px-6 text-center">
        <div className="max-w-[1100px] mx-auto">
          <AnimateIn>
            <h2 className="text-3xl md:text-[2.75rem] font-extrabold tracking-tight text-white max-w-[700px] mx-auto mb-4">
              Ready to Document Your<br />Organization's Brain?
            </h2>
            <p className="text-zinc-400 max-w-[540px] mx-auto mb-11 leading-relaxed">
              Scale the EMPOWER methodology across your entire workforce. Move from scattered
              AI experiments to systematic documentation that makes AI adoption actually work.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button className="bg-white text-zinc-950 font-bold text-base px-7 py-3.5 rounded-xl hover:opacity-88 transition-opacity">
                Enroll My Team
              </button>
              <button className="bg-transparent text-white border border-white/22 font-semibold text-base px-7 py-3.5 rounded-xl hover:border-white/50 hover:bg-white/7 transition-all">
                View Roadmap
              </button>
            </div>
            <div className="flex flex-col gap-2 mt-8 text-sm text-zinc-600">
              {['— Team-wide EMPOWER 101 access','— Centralized Master Context engine',
                '— Guided implementation rollout','— Department-specific workflow training','— Executive strategy workshop'].map(f => (
                <span key={f}>{f}</span>
              ))}
            </div>
          </AnimateIn>
        </div>
      </div>

      <Newsletter source="teams" />
      <Footer />
    </>
  )
}
