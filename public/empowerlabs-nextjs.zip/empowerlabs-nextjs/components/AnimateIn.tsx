'use client'

import { useEffect, useRef } from 'react'
import clsx from 'clsx'

type Props = {
  children: React.ReactNode
  className?: string
  direction?: 'up' | 'left' | 'right'
  delay?: 0 | 100 | 200 | 300 | 400
  threshold?: number
}

export default function AnimateIn({
  children,
  className,
  direction = 'up',
  delay = 0,
  threshold = 0.1,
}: Props) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add('revealed')
          observer.unobserve(el)
        }
      },
      { threshold, rootMargin: '0px 0px -36px 0px' }
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [threshold])

  const revealClass = {
    up:    'reveal',
    left:  'reveal-left',
    right: 'reveal-right',
  }[direction]

  const delayClass = delay ? `delay-${delay}` : ''

  return (
    <div ref={ref} className={clsx(revealClass, delayClass, className)}>
      {children}
    </div>
  )
}
