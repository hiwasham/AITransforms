import AnimateIn from './AnimateIn'

const CARDS = [
  { letter: 'E', name: 'Expansion',    desc: 'Scaling operations without complexity. Sale to Delivery & Delivery to Success.', accent: 'from-[#4a5f8a] to-[#8898c0]', bar: 'from-[#4a7fff] to-[#8b5cf6]' },
  { letter: 'M', name: 'Marketing',    desc: 'Brand strength & lead flow. Market to Lead & Success to Market.',                 accent: 'from-[#8b3a7a] to-[#d46fa0]', bar: 'from-[#d44fa0] to-[#8b3af0]' },
  { letter: 'P', name: 'Profitability',desc: 'Financial health & efficiency. Financial Performance Management.',                accent: 'from-[#2a7a4a] to-[#50c070]', bar: 'from-[#3da060] to-[#50e080]' },
  { letter: 'O', name: 'Offering',     desc: 'Sales effectiveness & conversion. Lead to Sale process optimization.',           accent: 'from-[#7a4a2a] to-[#c87840]', bar: 'from-[#c07030] to-[#f09040]' },
  { letter: 'W', name: 'Workforce',    desc: 'Recruit, develop, retain. Hire to Retire talent systems.',                      accent: 'from-[#8b2a6a] to-[#c860b8]', bar: 'from-[#c050c0] to-[#8040f0]' },
  { letter: 'E', name: 'Execution',    desc: 'Operational backbone. Quality Management & feedback loops.',                    accent: 'from-[#1a7a7a] to-[#30c0b0]', bar: 'from-[#20c0a0] to-[#00e0c0]' },
  { letter: 'R', name: 'Robustness',   desc: 'Market Position. Product Development & Future-proofing.',                      accent: 'from-[#5a3a8a] to-[#9060c8]', bar: 'from-[#8050d0] to-[#6040f0]' },
] as const

export default function EmperorCards() {
  return (
    <div className="bg-[#080e1c] py-24 px-6">
      <div className="max-w-[1100px] mx-auto">
        {/* Top row: 4 cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
          {CARDS.slice(0, 4).map((c, i) => (
            <AnimateIn key={c.name} delay={(i * 100) as 0|100|200|300}>
              <Card {...c} />
            </AnimateIn>
          ))}
        </div>
        {/* Bottom row: 3 cards centered */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-[825px] mx-auto">
          {CARDS.slice(4).map((c, i) => (
            <AnimateIn key={c.name} delay={(i * 100) as 0|100|200}>
              <Card {...c} />
            </AnimateIn>
          ))}
        </div>
      </div>
    </div>
  )
}

function Card({ letter, name, desc, accent, bar }: typeof CARDS[number]) {
  return (
    <div className="bg-[#0d1526] border border-[#1a2540] rounded-2xl p-5
      hover:border-[#2e4272] hover:-translate-y-1 transition-all duration-200
      hover:shadow-[0_20px_48px_rgba(0,0,0,0.45)] cursor-default">
      <span
        className={`block text-[64px] font-black leading-none tracking-tight mb-3
          bg-gradient-to-br ${accent} bg-clip-text text-transparent`}
      >
        {letter}
      </span>
      <div className="text-[0.7rem] font-bold tracking-[0.1em] uppercase text-[#e8eaf2] mb-1.5">
        {name}
      </div>
      <div className={`h-0.5 w-7 rounded-full bg-gradient-to-r ${bar} mb-2`} />
      <p className="text-[0.8rem] text-[#6b7a99] leading-[1.55]">{desc}</p>
    </div>
  )
}
