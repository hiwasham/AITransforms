import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-zinc-950 text-white pt-16 pb-8 px-6">
      <div className="max-w-[1100px] mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pb-10 border-b border-zinc-800 mb-7">
          <div>
            <div className="text-[1.08rem] font-black tracking-tight mb-3">
              EMPOWER<span className="text-blue-500">Labs</span>
            </div>
            <p className="text-sm text-zinc-600 leading-relaxed max-w-[260px]">
              Building the business brain for the next generation of business.
            </p>
          </div>

          <div>
            <h5 className="text-[0.7rem] font-bold tracking-[0.1em] uppercase text-zinc-600 mb-4">
              Programs
            </h5>
            <ul className="space-y-2.5">
              <li><Link href="/cohort" className="text-sm text-zinc-500 hover:text-white transition-colors">Live Cohort</Link></li>
              <li><Link href="/teams"  className="text-sm text-zinc-500 hover:text-white transition-colors">For Teams</Link></li>
              <li><Link href="/masterclass-replay" className="text-sm text-zinc-500 hover:text-white transition-colors">Masterclass Replay</Link></li>
            </ul>
          </div>

          <div>
            <h5 className="text-[0.7rem] font-bold tracking-[0.1em] uppercase text-zinc-600 mb-4">
              Contact
            </h5>
            <ul className="space-y-2.5">
              <li>
                <a href="mailto:support@empowerlabs.ai" className="text-sm text-zinc-500 hover:text-white transition-colors">
                  support@empowerlabs.ai
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-zinc-700">© 2026 EMPOWER Labs. All rights reserved.</p>
          <div className="flex gap-5">
            <Link href="/terms"   className="text-xs text-zinc-700 hover:text-zinc-400 transition-colors">Terms of Service</Link>
            <Link href="/privacy" className="text-xs text-zinc-700 hover:text-zinc-400 transition-colors">Privacy Policy</Link>
            <button className="text-xs text-zinc-700 hover:text-zinc-400 transition-colors">Cookie Preferences</button>
          </div>
        </div>
      </div>
    </footer>
  )
}
