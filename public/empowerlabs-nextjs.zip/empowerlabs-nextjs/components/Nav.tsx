'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Nav() {
  const [scrolled, setScrolled]   = useState(false)
  const [menuOpen, setMenuOpen]   = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 16)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  // Close mobile menu on route change
  useEffect(() => setMenuOpen(false), [pathname])

  // Lock body scroll when menu open
  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
  }, [menuOpen])

  const navLink = (href: string, label: string) => (
    <Link
      href={href}
      className={`text-sm font-medium px-3.5 py-2 rounded-lg transition-colors duration-150
        ${pathname === href
          ? 'text-zinc-900 bg-zinc-100'
          : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'
        }`}
    >
      {label}
    </Link>
  )

  return (
    <>
      <nav
        className={`sticky top-0 z-50 bg-white/85 backdrop-blur-xl border-b transition-all duration-300
          ${scrolled ? 'border-zinc-200 shadow-sm' : 'border-transparent'}`}
      >
        <div className="max-w-[1180px] mx-auto flex items-center justify-between h-16 px-6">
          {/* Logo */}
          <Link href="/" className="text-[1.08rem] font-black tracking-tight">
            EMPOWER<span className="text-blue-600">Labs</span>
          </Link>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-1">
            {navLink('/cohort', 'Live Cohort')}
            {navLink('/teams', 'For Teams')}
            <Link
              href="/#path"
              className="ml-2 bg-zinc-950 text-white text-sm font-bold px-5 py-2.5 rounded-xl
                transition-opacity duration-150 hover:opacity-85"
            >
              Get Started
            </Link>
          </div>

          {/* Hamburger */}
          <button
            className="md:hidden flex flex-col gap-[5px] p-2 rounded-lg hover:bg-zinc-100 transition-colors"
            onClick={() => setMenuOpen(v => !v)}
            aria-label="Toggle menu"
          >
            <span className={`block w-5.5 h-0.5 bg-zinc-900 rounded transition-transform duration-300
              ${menuOpen ? 'translate-y-[7px] rotate-45' : ''}`} />
            <span className={`block w-5.5 h-0.5 bg-zinc-900 rounded transition-all duration-300
              ${menuOpen ? 'opacity-0 scale-x-0' : ''}`} />
            <span className={`block w-5.5 h-0.5 bg-zinc-900 rounded transition-transform duration-300
              ${menuOpen ? '-translate-y-[7px] -rotate-45' : ''}`} />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div className={`fixed inset-0 z-40 bg-white flex flex-col pt-20 px-8 pb-10 transition-transform duration-350
        ${menuOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <Link href="/"       className="text-2xl font-bold py-5 border-b border-zinc-100 text-zinc-700">Home</Link>
        <Link href="/cohort" className="text-2xl font-bold py-5 border-b border-zinc-100 text-zinc-700">Live Cohort</Link>
        <Link href="/teams"  className="text-2xl font-bold py-5 border-b border-zinc-100 text-zinc-700">For Teams</Link>
        <Link href="/cohort" className="mt-7 bg-zinc-950 text-white text-xl font-bold py-5 rounded-2xl text-center">
          Get Started →
        </Link>
      </div>
    </>
  )
}
