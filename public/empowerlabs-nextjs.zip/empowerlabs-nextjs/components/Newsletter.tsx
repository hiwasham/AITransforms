'use client'

import { useState } from 'react'

type Props = { source?: 'newsletter' | 'cohort' | 'teams' }

export default function Newsletter({ source = 'newsletter' }: Props) {
  const [email,   setEmail]   = useState('')
  const [status,  setStatus]  = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [message, setMessage] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('loading')

    const res = await fetch('/api/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, source }),
    })

    const data = await res.json()

    if (res.ok) {
      setStatus('success')
      setMessage("You're subscribed. Welcome to the community.")
      setEmail('')
    } else {
      setStatus('error')
      setMessage(data.error || 'Something went wrong. Please try again.')
    }
  }

  return (
    <div className="bg-zinc-100 py-20 px-6 text-center">
      <div className="max-w-[460px] mx-auto">
        <p className="text-[0.7rem] font-bold tracking-[0.12em] uppercase text-zinc-500 mb-3">
          The EMPOWER Weekly
        </p>
        <h3 className="text-2xl font-extrabold tracking-tight mb-2.5">
          Build your business brain.
        </h3>
        <p className="text-sm text-zinc-600 mb-6 leading-relaxed">
          Join a growing community of forward-thinking founders receiving weekly
          insights on systems, AI governance, and scaling without chaos.
        </p>

        {status === 'success' ? (
          <p className="font-semibold text-zinc-600">
            ✓ {message}
          </p>
        ) : (
          <>
            <form
              onSubmit={handleSubmit}
              className="flex gap-2"
            >
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Your email address"
                required
                className="flex-1 px-4 py-3 rounded-xl border border-zinc-200 text-sm
                  focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10
                  bg-white transition-all"
              />
              <button
                type="submit"
                disabled={status === 'loading'}
                className="bg-zinc-950 text-white font-bold text-sm px-5 py-3 rounded-xl
                  hover:opacity-85 transition-opacity disabled:opacity-50 whitespace-nowrap"
              >
                {status === 'loading' ? '...' : 'Subscribe'}
              </button>
            </form>

            {status === 'error' && (
              <p className="text-red-500 text-xs mt-2">{message}</p>
            )}

            <p className="text-xs text-zinc-400 mt-3">
              I agree to the{' '}
              <a href="/privacy" className="underline underline-offset-2">Privacy Policy</a>
              {' '}and consent to receive updates.
            </p>
            <p className="text-xs text-zinc-400 mt-1">
              We hate spam as much as you do. Unsubscribe anytime.
            </p>
          </>
        )}
      </div>
    </div>
  )
}
