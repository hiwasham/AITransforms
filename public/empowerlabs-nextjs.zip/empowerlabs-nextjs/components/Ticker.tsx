'use client'

const LOGOS = [
  'Walmart','Meta','FanDuel','KOSATEC','Veritas Steel','RealWealth',
  'Rocket Media','Davids','Sharda Motor','ArcStone','Bruce & Merrilees',
  'Washmen','Digital DJ Tips','Camp Cocker','Langschied','The Egg Company',
  'cultivate(software)','Amber Premium',
]

export default function Ticker() {
  // Duplicate for seamless loop
  const items = [...LOGOS, ...LOGOS]

  return (
    <div className="bg-zinc-950 border-t border-zinc-800 border-b border-zinc-800 py-5 overflow-hidden">
      <p className="text-center text-[0.7rem] font-semibold tracking-[0.12em] uppercase text-zinc-700 mb-4">
        Trusted by forward-thinking organizations
      </p>
      <div className="ticker-mask overflow-hidden">
        <div className="flex gap-14 w-max animate-ticker hover:[animation-play-state:paused]">
          {items.map((logo, i) => (
            <span
              key={i}
              className="text-[0.875rem] font-bold text-zinc-700 whitespace-nowrap
                hover:text-zinc-400 transition-colors cursor-default"
            >
              {logo}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
