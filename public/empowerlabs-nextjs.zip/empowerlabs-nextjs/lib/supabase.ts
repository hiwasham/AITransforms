import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

// ─── BROWSER CLIENT (anon key — safe for client components) ──────────────────
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// ─── SERVER CLIENT (service role — only for API routes, never client-side) ───
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false },
})

// ─── TYPE DEFINITIONS ─────────────────────────────────────────────────────────
export type Subscriber = {
  id: string
  email: string
  source: 'newsletter' | 'cohort' | 'teams'
  created_at: string
  confirmed: boolean
}

export type CohortApplication = {
  id: string
  full_name: string
  email: string
  company?: string
  role?: string
  team_size?: string
  message?: string
  status: 'pending' | 'reviewed' | 'accepted' | 'rejected'
  created_at: string
}

export type TeamInquiry = {
  id: string
  full_name: string
  email: string
  company?: string
  team_size?: string
  message?: string
  status: 'pending' | 'contacted' | 'converted' | 'closed'
  created_at: string
}
