// ─── WordPress REST API Client ────────────────────────────────────────────────
// Fetches content from your WordPress site via the built-in REST API.
// No plugins needed — WordPress exposes /wp-json/wp/v2/* by default.
// ─────────────────────────────────────────────────────────────────────────────

const WP_URL = process.env.WORDPRESS_URL || 'https://empowerlabs.ai'
const WP_API = `${WP_URL}/wp-json/wp/v2`

export type WPPost = {
  id: number
  slug: string
  title: { rendered: string }
  excerpt: { rendered: string }
  content: { rendered: string }
  date: string
  featured_media: number
  _embedded?: {
    'wp:featuredmedia'?: Array<{
      source_url: string
      alt_text: string
    }>
    author?: Array<{ name: string; avatar_urls: Record<string, string> }>
  }
}

export type WPPage = {
  id: number
  slug: string
  title: { rendered: string }
  content: { rendered: string }
  acf?: Record<string, unknown> // Advanced Custom Fields data if you use ACF plugin
}

// ─── FETCH POSTS ──────────────────────────────────────────────────────────────
export async function getPosts(options?: {
  perPage?: number
  page?: number
  categorySlug?: string
}): Promise<WPPost[]> {
  const params = new URLSearchParams({
    per_page: String(options?.perPage ?? 6),
    page: String(options?.page ?? 1),
    _embed: 'true',       // Includes featured image and author in response
    status: 'publish',
  })

  if (options?.categorySlug) {
    // First get category ID from slug
    const catRes = await fetch(`${WP_API}/categories?slug=${options.categorySlug}`)
    const cats = await catRes.json()
    if (cats[0]) params.set('categories', cats[0].id)
  }

  const res = await fetch(`${WP_API}/posts?${params}`, {
    next: { revalidate: 3600 }, // Cache for 1 hour (ISR)
  })

  if (!res.ok) return []
  return res.json()
}

// ─── FETCH SINGLE POST ────────────────────────────────────────────────────────
export async function getPost(slug: string): Promise<WPPost | null> {
  const res = await fetch(`${WP_API}/posts?slug=${slug}&_embed=true`, {
    next: { revalidate: 3600 },
  })

  if (!res.ok) return null
  const posts = await res.json()
  return posts[0] ?? null
}

// ─── FETCH A WORDPRESS PAGE (not post) ───────────────────────────────────────
// Useful if you manage page content in WordPress (e.g. testimonials, FAQs)
export async function getWPPage(slug: string): Promise<WPPage | null> {
  const res = await fetch(`${WP_API}/pages?slug=${slug}&_embed=true`, {
    next: { revalidate: 3600 },
  })

  if (!res.ok) return null
  const pages = await res.json()
  return pages[0] ?? null
}

// ─── FETCH TESTIMONIALS (Custom Post Type) ────────────────────────────────────
// If you create a 'testimonials' custom post type in WordPress:
// Register it with: register_post_type('testimonials', ['show_in_rest' => true, ...])
export async function getTestimonials(): Promise<WPPost[]> {
  const res = await fetch(`${WP_API}/testimonials?per_page=10&_embed=true`, {
    next: { revalidate: 3600 },
  })

  if (!res.ok) return []
  return res.json()
}

// ─── HELPER: Strip HTML from WordPress content ────────────────────────────────
export function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, '').trim()
}

// ─── HELPER: Format WP date ───────────────────────────────────────────────────
export function formatWPDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })
}
