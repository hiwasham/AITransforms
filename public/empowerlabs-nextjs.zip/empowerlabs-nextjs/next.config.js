/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      // Your WordPress domain — change this to your actual WP domain
      {
        protocol: 'https',
        hostname: 'empowerlabs.ai',
        pathname: '/wp-content/**',
      },
      // If WordPress is on a subdomain
      {
        protocol: 'https',
        hostname: 'cms.empowerlabs.ai',
        pathname: '/wp-content/**',
      },
    ],
  },

  // When deploying Next.js ALONGSIDE WordPress on the same domain via nginx:
  // WordPress handles: /blog/*, /wp-admin/*, /wp-json/*
  // Next.js handles: everything else
  // Configure this in nginx — no Next.js config needed.

  // Optional: if WordPress is at a subdomain and you want to rewrite /blog/* to it
  async rewrites() {
    return [
      {
        source: '/blog/:path*',
        destination: `${process.env.WORDPRESS_URL}/blog/:path*`,
      },
    ]
  },
}

module.exports = nextConfig
