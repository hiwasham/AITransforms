-- ============================================================
-- EMPOWER Labs — Supabase Schema
-- Run this in: Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── NEWSLETTER SUBSCRIBERS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS subscribers (
  id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  email       text        UNIQUE NOT NULL,
  source      text        DEFAULT 'newsletter',  -- 'newsletter' | 'cohort' | 'teams'
  created_at  timestamptz DEFAULT now(),
  confirmed   boolean     DEFAULT false
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_subscribers_email ON subscribers(email);
CREATE INDEX IF NOT EXISTS idx_subscribers_created ON subscribers(created_at DESC);

-- ─── COHORT APPLICATIONS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cohort_applications (
  id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name   text        NOT NULL,
  email       text        NOT NULL,
  company     text,
  role        text,
  team_size   text,
  message     text,
  status      text        DEFAULT 'pending',  -- 'pending' | 'reviewed' | 'accepted' | 'rejected'
  source_page text        DEFAULT 'cohort',
  created_at  timestamptz DEFAULT now(),
  updated_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_cohort_status   ON cohort_applications(status);
CREATE INDEX IF NOT EXISTS idx_cohort_email    ON cohort_applications(email);
CREATE INDEX IF NOT EXISTS idx_cohort_created  ON cohort_applications(created_at DESC);

-- ─── TEAM INQUIRIES ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS team_inquiries (
  id          uuid        DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name   text        NOT NULL,
  email       text        NOT NULL,
  company     text,
  team_size   text,     -- '10-25' | '25-50' | '50-100' | '100-250' | '250+'
  message     text,
  status      text        DEFAULT 'pending',  -- 'pending' | 'contacted' | 'converted' | 'closed'
  created_at  timestamptz DEFAULT now(),
  updated_at  timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_teams_status  ON team_inquiries(status);
CREATE INDEX IF NOT EXISTS idx_teams_created ON team_inquiries(created_at DESC);

-- ─── ROW LEVEL SECURITY ──────────────────────────────────────────────────────
-- Enable RLS on all tables (only service role key can read — anon can only insert)
ALTER TABLE subscribers         ENABLE ROW LEVEL SECURITY;
ALTER TABLE cohort_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_inquiries      ENABLE ROW LEVEL SECURITY;

-- Allow anyone to insert (public form submissions)
CREATE POLICY "Anyone can subscribe"
  ON subscribers FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can apply to cohort"
  ON cohort_applications FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can submit team inquiry"
  ON team_inquiries FOR INSERT
  WITH CHECK (true);

-- Only service_role (your server) can read all rows
-- (Supabase Dashboard always shows all rows regardless)

-- ─── AUTO-UPDATE updated_at ───────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER cohort_updated_at
  BEFORE UPDATE ON cohort_applications
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER teams_updated_at
  BEFORE UPDATE ON team_inquiries
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── VERIFY ───────────────────────────────────────────────────────────────────
-- Run this to confirm everything was created:
SELECT table_name FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;
