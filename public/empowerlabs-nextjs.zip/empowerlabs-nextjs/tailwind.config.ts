/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          blue:    '#2563eb',
          'blue-l':'#3b82f6',
          'blue-xl':'#60a5fa',
          green:   '#22c55e',
          red:     '#ef4444',
          amber:   '#f59e0b',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        ticker: 'ticker 34s linear infinite',
        pulse:  'pulse 2s ease-in-out infinite',
        glow:   'glow 7s ease-in-out infinite',
        blink:  'blink .8s step-end infinite',
      },
      keyframes: {
        ticker: { from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
        glow: { '0%,100%': { opacity: '0.75' }, '50%': { opacity: '1' } },
        blink: { '0%,100%': { opacity: '1' }, '50%': { opacity: '0' } },
      },
    },
  },
  plugins: [],
}
